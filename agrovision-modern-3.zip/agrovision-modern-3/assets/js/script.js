
document.getElementById('contactForm')?.addEventListener('submit',function(e){
e.preventDefault();

let valid=true;

document.querySelectorAll('[required]').forEach(input=>{
if(input.value.trim()===''){
valid=false;
input.classList.add('is-invalid');
}else{
input.classList.remove('is-invalid');
}
});

if(valid){
alert('Form Submitted Successfully');
}
});
