
setInterval(()=>{
document.getElementById('time').innerHTML=new Date().toLocaleString();
},1000);

document.getElementById('contactForm')?.addEventListener('submit',function(e){
e.preventDefault();
alert('Form Submitted Successfully');
});
