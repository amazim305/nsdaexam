
document.getElementById('quizForm')?.addEventListener('submit',function(e){
e.preventDefault();

document.getElementById('result').innerHTML=
'<div class="alert alert-success mt-3">Recommended Plant: Snake Plant</div>';
});

document.getElementById('contactForm')?.addEventListener('submit',function(e){
e.preventDefault();
alert('Submitted Successfully');
});

setInterval(()=>{
document.getElementById('time').innerHTML=new Date().toLocaleString();
},1000);
