
document.getElementById('quizForm')?.addEventListener('submit',function(e){
e.preventDefault();

const sunlight=document.getElementById('sunlight').value;
const care=document.getElementById('care').value;

let result='Snake Plant';

if(sunlight==='Low' && care==='Easy'){
result='ZZ Plant';
}else if(sunlight==='Bright' && care==='Medium'){
result='Monstera Deliciosa';
}

document.getElementById('quizResult').innerHTML=
'Recommended Plant: <strong>'+result+'</strong>';
});

document.getElementById('contactForm')?.addEventListener('submit',function(e){
e.preventDefault();
alert('Submitted Successfully');
});

function updateTime(){
const now=new Date();
document.getElementById('datetime').innerHTML=now.toLocaleString();
}
setInterval(updateTime,1000);
