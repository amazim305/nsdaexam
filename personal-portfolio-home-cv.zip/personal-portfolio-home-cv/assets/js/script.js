
setInterval(()=>{
document.getElementById('time').innerHTML=new Date().toLocaleString();
},1000);

document.getElementById('contactForm')?.addEventListener('submit',function(e){
e.preventDefault();

const required=document.querySelectorAll('[required]');
let valid=true;

required.forEach(input=>{
if(input.value.trim()===''){
valid=false;
}
});

if(valid){
alert('Submitted Successfully');
}
});
