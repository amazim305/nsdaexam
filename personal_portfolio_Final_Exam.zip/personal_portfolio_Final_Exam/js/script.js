
function updateDateTime(){
    const now = new Date();
    document.getElementById("datetime").innerHTML = now.toLocaleString();
}

setInterval(updateDateTime,1000);

function validateForm(){
    let name = document.forms["contactForm"]["name"].value;
    let email = document.forms["contactForm"]["email"].value;
    let phone = document.forms["contactForm"]["phone"].value;
    let message = document.forms["contactForm"]["message"].value;

    if(name == "" || email == "" || phone == "" || message == ""){
        alert("Please fill all fields");
        return false;
    }

    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if(!email.match(emailPattern)){
        alert("Enter valid email");
        return false;
    }

    alert("Form submitted successfully!");
    return true;
}
