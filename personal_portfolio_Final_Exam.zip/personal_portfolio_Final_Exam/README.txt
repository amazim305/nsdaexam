
PERSONAL PORTFOLIO WEBSITE

Pages:
1. Home Page
2. About Page
3. Portfolio Page
4. Service Page
5. Contact Page

Technologies:
- HTML5
- CSS3
- JavaScript
- Bootstrap 5

Features:
- Fully Responsive
- Bootstrap Navbar
- Carousel Slider
- FAQ Accordion
- Contact Form Validation
- Google Map
- Live Date & Time Footer
- SEO Meta Tags
- External CSS & JS
